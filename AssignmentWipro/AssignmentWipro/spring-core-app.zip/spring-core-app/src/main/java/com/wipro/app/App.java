/*package com.wipro.app;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wipro.model.Employee;

public class App {


	public static void main(String[] args) {
		ApplicationContext context=null;
		try {
			//IoC container 			
			context= new ClassPathXmlApplicationContext("spring1.xml");
			Employee employee1= (Employee) context.getBean("empBean1");
			System.out.println(employee1);
			Employee employee2= (Employee) context.getBean("empBean2");
			System.out.println(employee1);
			
			
     		 //shutdown IoC 
			((AbstractApplicationContext)context).registerShutdownHook();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			((AbstractApplicationContext)context).close();
		}


	}


}*/
package com.wipro.app;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.wipro.model.Person;
public class App {
	public static void main(String[] args) {
		ApplicationContext context=null;
		try {
			//IoC container 			
//			context= new ClassPathXmlApplicationContext("spring1.xml");
//			context= new ClassPathXmlApplicationContext("spring2.xml");
			context= new ClassPathXmlApplicationContext("spring3.xml");
			
			Person person1 = (Person) context.getBean("personBean");
			//com.wipro.model.Person@6adbc9d
			System.out.println(person1);//packagename.classname@hexadecimal representation of object's hascode
			
			Person person2 = (Person) context.getBean("personBean");
			//com.wipro.model.Person@6adbc9d
			System.out.println(person2);
			
			 //shutdown IoC
			((AbstractApplicationContext)context).registerShutdownHook();
		}catch(Exception e) {
			e.printStackTrace();
		}finally {
			((AbstractApplicationContext)context).close();
		}
	}
}




