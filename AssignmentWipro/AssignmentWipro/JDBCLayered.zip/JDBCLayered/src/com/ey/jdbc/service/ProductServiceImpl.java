package com.ey.jdbc.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.ey.jdbc.model.Product;
import com.ey.jdbc.util.DbConn;

public class ProductServiceImpl implements ProductServicee {
	
	@Override
	public void insertProduct(Product product) throws SQLException, ClassNotFoundException {
		PreparedStatement pst=DbConn.getConnection().prepareStatement("insert into product values(?, ?, ?)");
		pst.setInt(1, product.getId());
		pst.setString(2, product.getName());
		pst.setDouble(3, product.getPrice());
		pst.execute();
	}
	
	@Override
	public void deleteProduct(Integer pid) throws SQLException, ClassNotFoundException {
        PreparedStatement pst=DbConn.getConnection().prepareStatement("delete from product where id=?");	
        pst.setInt(1, pid);
        pst.execute();
        
        System.out.println("Product delete");
	}
	
	@Override
	public void updateProduct(Integer pid, Product product) throws SQLException, ClassNotFoundException {
		Connection con = DbConn.getConnection();
		con.setAutoCommit(false);
		try {
			PreparedStatement pst = con.prepareStatement("update product set name=?, price=? where id=?");
			pst.setString(1, product.getName());
			pst.setDouble(2,product.getPrice());
			pst.setInt(3, pid);
			pst.execute();
			con.commit();
		} catch (Exception e) {
			con.rollback();
			e.printStackTrace();
		}
		
		System.out.println("Product updated");
	}
	
	@Override
	public List<Product> getAllProducts() throws SQLException, ClassNotFoundException {
		Statement st= DbConn.getConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = st.executeQuery("select * from product");
		List<Product> productList = new ArrayList<>();
		while (rs.next()) {
			Product p = new Product();
			p.setId(rs.getInt(1));
			p.setName(rs.getString(2));
			p.setPrice(rs.getDouble(3));
			productList.add(p);
		}
		return productList;
	}
	@Override
	public Product getProduct(Integer pid) throws SQLException, ClassNotFoundException {
		PreparedStatement pst  = DbConn.getConnection().prepareStatement("select*from product where id=?");
		pst.setInt(1, pid);
		ResultSet rs = pst.executeQuery();
		Product p = new Product();
		while (rs.next()){
			p.setId(rs.getInt(1));
			p.setName(rs.getString(2));
			p.setPrice(rs.getDouble(3));
			
		}
		return p;
	}

}
