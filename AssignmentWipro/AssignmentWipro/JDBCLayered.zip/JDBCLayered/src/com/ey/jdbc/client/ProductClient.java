package com.ey.jdbc.client;

import java.sql.SQLException;
import com.ey.jdbc.model.Product;
import com.ey.jdbc.service.ProductServicee;
import com.ey.jdbc.service.ProductServiceImpl;

public class ProductClient {
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		ProductServicee ps = new ProductServiceImpl();
		
		ps.insertProduct(new Product(101,"Laptop",54000.0));
		ps.insertProduct(new Product(102,"Fridge",50000.0));
		ps.insertProduct(new Product(103,"Cooler",40000.0));
		
		ps.getAllProducts().stream().forEach(p -> System.out.println(p));
	}

}
