package com.ey.jdbc.service;
import java.sql.SQLException;
import java.util.List;
import com.ey.jdbc.model.Product;

public interface ProductServicee {
	void insertProduct(Product product) throws SQLException, ClassNotFoundException;
	void deleteProduct(Integer pid) throws SQLException, ClassNotFoundException;
	void updateProduct(Integer pid, Product product) throws SQLException, ClassNotFoundException;
	List<Product> getAllProducts() throws SQLException, ClassNotFoundException;
	Product getProduct(Integer pid) throws SQLException, ClassNotFoundException;

}
