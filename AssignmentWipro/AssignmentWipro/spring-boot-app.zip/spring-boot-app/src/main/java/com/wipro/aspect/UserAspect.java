package com.wipro.aspect;

import org.aspectj.lang.annotation.Aspect;

@Aspect
public class UserAspect {

}
