package com.junit;

public class Sum {
	public int add(int a,int b) {
		return a+b;
	}
	
	public int prod(int a,int b) {
		return a*b;
	}
	public static void main(String[] args) {
		Sum s=new Sum();
		System.out.println(s.add(4, 5));
		System.out.println(s.prod(2,3));
	}
	
	

}
