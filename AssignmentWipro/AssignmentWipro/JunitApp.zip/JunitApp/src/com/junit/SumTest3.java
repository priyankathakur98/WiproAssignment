package com.junit;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class SumTest3 {
	Sum s;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
		s=new Sum();
	}

	@AfterEach
	void tearDown() throws Exception {
		s=null;
	}

	@Test
	void testAdd() {
		//expected, actual
		assertEquals(9,s.add(4, 5));
		assertNotNull(s.add(42,15));
		//fail("Not yet implemented");
	}
	@Test
	void testProd() {
		//expected, actual
		assertEquals(10,s.prod(2, 5));
		//fail("Not yet implemented");
	}
	

}
