package com.wipro.app;

public class CarPurchase {

}
