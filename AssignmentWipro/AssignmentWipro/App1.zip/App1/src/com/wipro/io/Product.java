/*package com.wipro.io;
import java.sql.*;

public class Product {
public static void main(String[] args) throws SQLException,ClassNotFoundException {
 		
		//step1  create driver
		Class.forName("oracle.jdbc.OracleDriver");
		
		//step2 create statement
	    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:9501/XE","system","rps@123");
		
		System.out.println("connection is success");
		
		//step3.creating statement
        Statement st = con.createStatement();
        
        
        //st.executeQuery("CREATE TABLE PRODUCTS(PROD_ID NUMBER(20) PRIMARY KEY, NAME VARCHAR(50) NOT NULL, QUANTITY NUMBER(5) CHECK(QUANTITY > 0))");
       //Inserting a new products
       //st.executeUpdate("INSERT INTO PRODUCTS VALUES (1,'Laptop',40000)");
       //st.executeUpdate("INSERT INTO PRODUCTS VALUES (2,'Cooler',30000)");
       //st.executeUpdate("INSERT INTO PRODUCTS VALUES (3,'Heater',2000)");
       st.executeUpdate("INSERT INTO PRODUCTS VALUES (4,'Fridge',25000)");
       System.out.println("Inserted Successfully");
       
       //st.executeUpdate("UPDATE PRODUCTS SET QUANTITY =60000 WHERE PROD_ID=4");
       //st.executeUpdate("DELETE FROM PRODUCTS WHERE PROD_ID= 2");
       
       //step4.execute statement
       //ResultSet rs = st.executeQuery("SELECT * FROM PRODUCTS ");
       
       //ResultSetMetaData rms = rs.getMetaData();
       //for(int i=1; i<=rms.getColumnCount();i++) {
    	   //System.out.print(rms.getColumnName(i) + " ");
       //}
       //System.out.println();
       
       
      // while(rs.next()) {
    	//   System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+ rs.getString(3));
       //}
       
       //step5. close the connection
       rs.close();
       st.close(); * 
       con.close();
       
        
	}
}*/


