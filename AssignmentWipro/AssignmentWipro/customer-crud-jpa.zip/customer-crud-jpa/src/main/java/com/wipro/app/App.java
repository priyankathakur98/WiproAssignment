package com.wipro.app;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

import com.wipro.entity.Book;
import com.wipro.entity.Customer;
import com.wipro.service.BookService;
import com.wipro.service.BookServiceImpl;
public class App {
	
//    private static CustomerService service = new CustomerServiceImpl();
	private static BookService service = new BookServiceImpl();
    
	public static void main(String[] args) {
//		service.addCustomer(new Customer(null,"priyanka","priyanka@gmail.com",8937434523l));
//		service.addCustomer(new Customer(null,"kajal","kajal@gmail.com",8037434523l));
		
//		Customer customer1 =service.getCustomerById(1);
//		System.out.println (customer1);
		
//		Customer customer2=service.getCustomerById(2);
//		System.out.println(customer2);
		
//		List<Customer> customerList = service.getAllCustomers();
//		Iterator<Customer> iterator= customerList.iterator();
//		while(iterator.hasNext())
//		{
//			System.out.println(iterator.next());
//		}
		
//		Customer customer1= service.getCustomerById(1);
//		System.out.println("Before : "+customer1);
//		customer1.setEmail("priyanka@gmail.com");
		
//		String status = service.updatecustomer(customer1);
//		System.out.println(status);
//		Customer custome12= service.getCustomerById(1);
//		System.out.println("After : "+customer1);
//		System.out.println(status);
		
//		List<Customer> customerList = service.getAllCustomers();
//		Iterator<Customer> iterator= customerList.iterator();
//		while(iterator.hasNext())
//		{
//			System.out.println(iterator.next());
//		}
		
		
		
//		service.addBook(new Book(null,"Book1","abc",LocalDate.of(2021, 06, 05),699.0));
//		service.addBook(new Book(null,"Book2","yuc",LocalDate.of(2022, 05, 21),890.0));
//		service.addBook(new Book(null,"Book3","jkc",LocalDate.of(2020, 06, 05),679.0));
//		service.addBook(new Book(null,"Book4","kbc",LocalDate.of(2020, 06, 05),899.0));
		
//		List<Book> bookList = service.getAllBooks();
//		Iterator<Book> iterator = bookList.iterator();
//		while(iterator.hasNext())
//			{
//				System.out.println(iterator.next());
//			}
		
//		String status = service.deleteBook(52);
//		String status1 = service.deleteBook(53);
//		String status2 = service.deleteBook(54);
//		String status3 = service.deleteBook(55);
		
//		List<Book> bookList = service.getBooksByAuthor("abc");
//		Iterator<Book> iterator = bookList.iterator();
//		while(iterator.hasNext()) {
//			System.out.println(iterator.next());
//		}
		
//		List<Book> bookList = service.getBooksByAuthorGreateThanPrice("abc", 600.0);
		
//		Iterator<Book> iterator = bookList.iterator();
//		while(iterator.hasNext())
//			{
//				System.out.println(iterator.next());
		
//			}
		
        List<Book> bookList = service.fetchAllBooks();
		
		Iterator<Book> iterator = bookList.iterator();
		while(iterator.hasNext())
			{
				System.out.println(iterator.next());
			}
	}

}
